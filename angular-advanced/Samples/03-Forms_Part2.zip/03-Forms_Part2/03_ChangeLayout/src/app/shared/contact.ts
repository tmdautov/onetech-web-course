export interface Contact {
    id: number;
    name: string;
    age: number
}