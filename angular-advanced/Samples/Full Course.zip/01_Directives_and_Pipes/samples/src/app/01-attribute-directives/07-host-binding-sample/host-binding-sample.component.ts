import { Component } from "@angular/core";

@Component({
  selector: "app-host-binding-sample",
  templateUrl: "./host-binding-sample.component.html",
  styles: [".pressed { background-color: red; color: white }"]
})
export class HostBindingSampleComponent {

}
