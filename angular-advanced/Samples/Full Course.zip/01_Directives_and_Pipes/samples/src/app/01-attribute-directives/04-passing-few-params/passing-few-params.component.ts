import { Component } from "@angular/core";

@Component({
  selector: "app-passing-few-params",
  templateUrl: "./passing-few-params.component.html"
})
export class PassingFewParamsComponent {


}
