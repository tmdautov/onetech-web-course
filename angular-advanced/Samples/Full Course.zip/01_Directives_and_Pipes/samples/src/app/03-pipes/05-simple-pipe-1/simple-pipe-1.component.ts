import { Component } from "@angular/core";

@Component({
  selector: "app-simple-pipe-1",
  templateUrl: "./simple-pipe-1.component.html"
})
export class SimplePipe1Component {
  
  value: number;

}
