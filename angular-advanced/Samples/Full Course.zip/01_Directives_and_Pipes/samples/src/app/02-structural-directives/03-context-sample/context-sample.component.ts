import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-context-sample",
  templateUrl: "./context-sample.component.html"
})
export class ContextSampleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
