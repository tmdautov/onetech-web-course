import { Component } from "@angular/core";

@Component({
  selector: "app-chaining-sample",
  templateUrl: "./chaining-sample.component.html"
})
export class ChainingSampleComponent {

  creationDate: Date = new Date();

}
