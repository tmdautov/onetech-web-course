import { Component } from "@angular/core";

@Component({
  selector: "app-simple-pipe-2",
  templateUrl: "./simple-pipe-2.component.html"
})
export class SimplePipe2Component {
  value: number;
}
