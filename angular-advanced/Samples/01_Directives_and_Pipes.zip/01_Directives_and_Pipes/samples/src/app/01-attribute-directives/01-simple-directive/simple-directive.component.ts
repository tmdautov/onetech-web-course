import { Component } from "@angular/core";

@Component({
  selector: "app-simple-directive",
  templateUrl: "./simple-directive.component.html"
})
export class SimpleDirectiveComponent {
}
