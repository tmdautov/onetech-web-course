import { Component } from "@angular/core";

@Component({
  selector: "app-event-directive",
  templateUrl: "./event-directive.component.html"
})
export class EventDirectiveComponent {


}
