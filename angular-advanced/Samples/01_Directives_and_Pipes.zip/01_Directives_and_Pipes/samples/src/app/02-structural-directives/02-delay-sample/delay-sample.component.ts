import { Component } from "@angular/core";

@Component({
  selector: "app-delay-sample",
  templateUrl: "./delay-sample.component.html"
})
export class DelaySampleComponent {

}
